# Synthetic Coin Platform

Repository structure ready for deployment.